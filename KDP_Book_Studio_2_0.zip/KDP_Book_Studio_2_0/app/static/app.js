
const $=id=>document.getElementById(id);
function data(){
 return {title:$("title").value,subtitle:$("subtitle").value,author:$("author").value,language:$("language").value,
 type:$("type").value,theme:$("theme").value,audience:$("audience").value,tone:$("tone").value,
 width:$("width").value,height:$("height").value,pages:$("pages").value,activities:$("activities").value,
 paper:$("paper").value,interior:$("interior").value,bleed:$("bleed").checked};
}
$("build").onclick=async()=>{
 const r=await fetch("/api/plan",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data())});
 const p=await r.json();$("result").classList.remove("hidden");
 $("summary").innerHTML=`<span class="metric">📖 ${p.spec.pages} pagine</span><span class="metric">📐 ${p.spec.trim_width_in} × ${p.spec.trim_height_in}"</span><span class="metric">📏 margine interno ${p.spec.margins.inside_in}"</span><span class="metric">🎨 bleed ${p.spec.bleed?"Sì":"No"}</span><span class="metric">📕 dorso ${p.spec.cover.spine_in}"</span>`;
 $("sections").innerHTML=p.sections.map(s=>`<div class="section"><b>${s.number}. ${s.title}</b><br><small>${s.purpose} ${s.activity?"• attività prevista":""}</small></div>`).join("");
 $("preflight").innerHTML=`<div class="ok">✓ Specifiche tecniche calcolate</div><div class="ok">✓ Margini proporzionati al numero di pagine</div><div class="ok">✓ Dimensioni copertina calcolate</div><div class="warn">⚠ Il controllo finale va eseguito anche nel Print Previewer di KDP</div>`;
};
$("coverBtn").onclick=async()=>{
 const r=await fetch("/api/cover",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data())});const c=await r.json();
 alert(`Copertina completa: ${c.cover_width_in}" × ${c.cover_height_in}"\\nDorso: ${c.spine_in}"`);
};
$("exportBtn").onclick=async()=>{
 const r=await fetch("/api/export-project",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data())});const x=await r.json();
 location.href="/output/"+encodeURIComponent(x.file);
};
$("reviewBtn").onclick=async()=>{
 const r=await fetch("/api/review",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text:$("reviewText").value})});const x=await r.json();
 $("reviewResult").innerHTML=`<p><b>Indice preliminare:</b> ${x.score}/100</p>`+(x.issues.length?x.issues.map(i=>`<p class="warn">⚠ ${i.message}</p>`).join(""):`<p class="ok">✓ Nessun problema semplice rilevato.</p>`);
};
